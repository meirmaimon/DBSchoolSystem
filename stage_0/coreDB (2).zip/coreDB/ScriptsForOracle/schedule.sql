INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,2190855,to_date('28/09/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,2190855,to_date('30/09/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,2190855,to_date('9/03/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,2190855,to_date('2/12/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,3389828,to_date('15/09/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,3389828,to_date('11/07/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,3389828,to_date('12/08/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,3389828,to_date('7/12/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,5000929,to_date('24/02/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,5000929,to_date('14/10/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,5000929,to_date('8/07/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,5000929,to_date('3/07/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,6894158,to_date('6/12/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,6894158,to_date('22/05/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,6894158,to_date('25/06/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,6894158,to_date('7/11/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,8128654,to_date('20/07/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,8128654,to_date('14/09/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,8128654,to_date('13/02/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,8128654,to_date('19/03/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,15801086,to_date('24/05/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,15801086,to_date('30/03/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,15801086,to_date('5/03/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,15801086,to_date('26/02/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,19170372,to_date('20/05/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,19170372,to_date('21/01/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,19170372,to_date('3/08/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,19170372,to_date('23/01/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752297328,19362329,to_date('11/01/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752297328,19362329,to_date('5/01/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752297328,19362329,to_date('18/10/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752297328,19362329,to_date('30/11/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,20764142,to_date('15/05/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,20764142,to_date('22/03/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,20764142,to_date('28/02/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,20764142,to_date('15/09/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,22939325,to_date('31/07/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,22939325,to_date('1/03/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,22939325,to_date('18/04/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,22939325,to_date('4/03/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,24598464,to_date('8/04/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,24598464,to_date('15/01/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,24598464,to_date('25/07/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,24598464,to_date('30/06/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,27865530,to_date('23/11/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,27865530,to_date('11/05/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,27865530,to_date('6/01/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,27865530,to_date('28/06/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,44635211,to_date('25/05/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,44635211,to_date('16/06/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,44635211,to_date('9/06/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,44635211,to_date('31/01/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,45431070,to_date('11/02/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,45431070,to_date('2/12/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,45431070,to_date('31/12/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,45431070,to_date('30/10/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,63866084,to_date('10/11/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,63866084,to_date('10/04/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,63866084,to_date('1/04/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,63866084,to_date('16/04/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,69212955,to_date('9/06/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,69212955,to_date('1/02/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,69212955,to_date('20/02/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,69212955,to_date('7/06/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,72356355,to_date('4/12/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,72356355,to_date('22/09/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,72356355,to_date('5/10/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,72356355,to_date('22/07/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (676752878,72999236,to_date('15/11/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (676752878,72999236,to_date('25/11/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (676752878,72999236,to_date('2/11/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (676752878,72999236,to_date('10/08/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,73650446,to_date('8/11/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,73650446,to_date('2/06/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,73650446,to_date('3/11/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,73650446,to_date('16/05/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,78110558,to_date('17/12/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,78110558,to_date('8/06/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,78110558,to_date('10/02/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,78110558,to_date('10/04/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,80186057,to_date('9/06/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,80186057,to_date('7/08/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,80186057,to_date('24/09/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,80186057,to_date('25/08/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,88099555,to_date('16/02/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,88099555,to_date('29/03/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,88099555,to_date('22/11/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,88099555,to_date('25/10/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,88526497,to_date('30/03/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,88526497,to_date('4/05/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,88526497,to_date('5/08/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,88526497,to_date('20/06/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,88627833,to_date('29/04/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,88627833,to_date('23/11/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,88627833,to_date('2/09/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,88627833,to_date('25/09/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,91460284,to_date('12/06/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,91460284,to_date('28/04/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,91460284,to_date('3/11/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,91460284,to_date('25/11/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,92740097,to_date('29/07/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,92740097,to_date('19/08/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,92740097,to_date('4/10/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,92740097,to_date('7/06/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,98417664,to_date('6/08/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,98417664,to_date('16/04/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,98417664,to_date('23/08/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,98417664,to_date('7/05/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,98940245,to_date('3/03/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,98940245,to_date('26/06/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,98940245,to_date('21/02/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,98940245,to_date('7/03/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,103047956,to_date('20/02/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,103047956,to_date('20/04/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,103047956,to_date('30/05/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,103047956,to_date('3/02/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (676752878,110555065,to_date('6/09/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (676752878,110555065,to_date('24/08/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (676752878,110555065,to_date('2/10/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (676752878,110555065,to_date('28/04/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,115115939,to_date('28/11/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,115115939,to_date('8/10/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,115115939,to_date('22/09/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,115115939,to_date('3/09/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (660084321,115643127,to_date('16/10/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (660084321,115643127,to_date('4/02/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (660084321,115643127,to_date('2/08/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (660084321,115643127,to_date('5/10/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,117101011,to_date('15/03/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,117101011,to_date('26/12/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,117101011,to_date('19/06/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,117101011,to_date('2/11/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,121049253,to_date('17/03/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,121049253,to_date('7/04/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,121049253,to_date('2/02/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,121049253,to_date('10/08/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,123135613,to_date('3/11/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,123135613,to_date('21/04/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,123135613,to_date('21/02/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,123135613,to_date('12/03/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,124789264,to_date('11/04/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,124789264,to_date('26/04/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,124789264,to_date('14/03/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,124789264,to_date('17/10/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,131213514,to_date('25/12/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,131213514,to_date('18/02/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,131213514,to_date('23/07/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,131213514,to_date('24/10/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,132553719,to_date('19/06/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,132553719,to_date('29/10/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,132553719,to_date('22/02/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,132553719,to_date('30/01/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,132793121,to_date('29/10/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,132793121,to_date('16/10/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,132793121,to_date('1/04/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,132793121,to_date('1/08/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,136037603,to_date('31/07/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,136037603,to_date('27/02/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,136037603,to_date('7/07/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,136037603,to_date('29/09/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,145310425,to_date('17/04/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,145310425,to_date('4/01/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,145310425,to_date('27/11/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,145310425,to_date('19/05/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (753128485,153676885,to_date('15/11/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (753128485,153676885,to_date('28/03/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (753128485,153676885,to_date('15/02/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (753128485,153676885,to_date('5/07/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (564441324,156366795,to_date('9/03/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (564441324,156366795,to_date('28/12/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (564441324,156366795,to_date('14/03/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (564441324,156366795,to_date('13/08/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,159142131,to_date('10/03/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,159142131,to_date('11/08/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,159142131,to_date('6/06/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,159142131,to_date('9/10/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,159670900,to_date('20/06/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,159670900,to_date('10/05/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,159670900,to_date('30/03/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,159670900,to_date('31/05/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,168709173,to_date('10/04/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,168709173,to_date('9/05/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,168709173,to_date('21/02/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (650823903,168709173,to_date('26/09/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,181999773,to_date('14/07/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,181999773,to_date('20/03/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,181999773,to_date('30/10/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,181999773,to_date('27/06/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,192493886,to_date('8/03/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,192493886,to_date('21/09/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,192493886,to_date('11/04/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,192493886,to_date('26/12/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,194361758,to_date('26/03/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,194361758,to_date('8/03/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,194361758,to_date('12/11/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,194361758,to_date('30/01/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,210124207,to_date('9/08/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,210124207,to_date('28/05/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,210124207,to_date('15/11/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,210124207,to_date('29/11/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,212847947,to_date('14/06/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,212847947,to_date('26/02/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,212847947,to_date('22/07/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,212847947,to_date('28/02/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,219426202,to_date('21/09/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,219426202,to_date('22/09/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,219426202,to_date('3/11/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,219426202,to_date('27/02/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (604117504,234980567,to_date('11/04/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (604117504,234980567,to_date('27/04/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (604117504,234980567,to_date('5/08/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (604117504,234980567,to_date('12/11/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,248389204,to_date('13/06/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,248389204,to_date('11/07/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,248389204,to_date('21/06/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,248389204,to_date('8/07/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,249654624,to_date('26/05/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,249654624,to_date('8/06/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,249654624,to_date('13/02/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,249654624,to_date('16/05/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,259683399,to_date('22/07/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,259683399,to_date('19/08/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,259683399,to_date('10/11/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,259683399,to_date('21/05/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,264966244,to_date('12/04/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,264966244,to_date('7/08/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,264966244,to_date('11/06/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,264966244,to_date('19/06/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,265186844,to_date('19/09/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,265186844,to_date('12/02/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,265186844,to_date('8/05/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,265186844,to_date('22/12/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,272029654,to_date('22/01/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,272029654,to_date('1/09/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,272029654,to_date('1/05/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (683733405,272029654,to_date('23/03/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,278320006,to_date('25/12/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,278320006,to_date('5/02/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,278320006,to_date('19/11/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,278320006,to_date('19/03/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,280714288,to_date('8/02/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,280714288,to_date('21/09/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,280714288,to_date('15/08/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,280714288,to_date('23/04/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (681442399,289243756,to_date('11/06/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (681442399,289243756,to_date('7/01/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (681442399,289243756,to_date('16/05/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (681442399,289243756,to_date('28/04/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,310072080,to_date('5/02/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,310072080,to_date('23/06/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,310072080,to_date('5/07/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,310072080,to_date('1/02/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,310463668,to_date('6/05/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,310463668,to_date('21/02/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,310463668,to_date('11/01/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,310463668,to_date('2/04/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (654534078,322919777,to_date('5/01/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (654534078,322919777,to_date('8/01/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (654534078,322919777,to_date('20/03/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (654534078,322919777,to_date('8/08/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752356052,332265480,to_date('27/08/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752356052,332265480,to_date('10/09/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752356052,332265480,to_date('17/08/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752356052,332265480,to_date('29/07/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752297328,335190933,to_date('24/05/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752297328,335190933,to_date('28/06/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752297328,335190933,to_date('25/03/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752297328,335190933,to_date('9/03/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,338857608,to_date('29/07/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,338857608,to_date('24/08/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,338857608,to_date('3/03/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,338857608,to_date('28/02/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,341853362,to_date('6/04/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,341853362,to_date('30/01/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,341853362,to_date('31/08/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (607968105,341853362,to_date('15/04/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,344933268,to_date('25/10/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,344933268,to_date('11/05/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,344933268,to_date('27/03/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,344933268,to_date('8/01/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,350401127,to_date('31/03/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,350401127,to_date('28/02/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,350401127,to_date('17/01/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597322737,350401127,to_date('11/02/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,354363890,to_date('22/06/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,354363890,to_date('10/06/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,354363890,to_date('4/02/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,354363890,to_date('16/09/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (725287167,364340715,to_date('25/11/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (725287167,364340715,to_date('8/12/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (725287167,364340715,to_date('10/04/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (725287167,364340715,to_date('3/11/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,378745145,to_date('22/12/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,378745145,to_date('15/01/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,378745145,to_date('25/10/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,378745145,to_date('22/04/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,382381035,to_date('18/03/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,382381035,to_date('5/08/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,382381035,to_date('9/02/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,382381035,to_date('22/08/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,382463885,to_date('14/01/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,382463885,to_date('18/04/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,382463885,to_date('7/12/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (724732338,382463885,to_date('7/06/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (661492247,383479888,to_date('4/10/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (661492247,383479888,to_date('24/11/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (661492247,383479888,to_date('27/10/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (661492247,383479888,to_date('27/06/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (654534078,388665252,to_date('28/09/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (654534078,388665252,to_date('28/09/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (654534078,388665252,to_date('26/07/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (654534078,388665252,to_date('16/10/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,393330959,to_date('9/08/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,393330959,to_date('28/02/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,393330959,to_date('11/02/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,393330959,to_date('15/01/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (756787165,394225733,to_date('30/06/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (756787165,394225733,to_date('10/05/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (756787165,394225733,to_date('10/06/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (756787165,394225733,to_date('23/04/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (604117504,403013933,to_date('1/11/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (604117504,403013933,to_date('3/09/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (604117504,403013933,to_date('21/10/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (604117504,403013933,to_date('15/06/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,410481877,to_date('29/10/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,410481877,to_date('24/07/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,410481877,to_date('11/05/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,410481877,to_date('24/11/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,420481521,to_date('29/04/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,420481521,to_date('1/01/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,420481521,to_date('21/10/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (726327922,420481521,to_date('27/12/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,435638147,to_date('27/08/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,435638147,to_date('15/06/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,435638147,to_date('25/07/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,435638147,to_date('12/12/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,435914771,to_date('11/06/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,435914771,to_date('26/02/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,435914771,to_date('2/11/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,435914771,to_date('4/01/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (753128485,436218147,to_date('8/03/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (753128485,436218147,to_date('16/06/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (753128485,436218147,to_date('3/10/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (753128485,436218147,to_date('4/09/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,440908369,to_date('6/07/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,440908369,to_date('3/10/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,440908369,to_date('3/07/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,440908369,to_date('28/09/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,441865261,to_date('19/03/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,441865261,to_date('11/04/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,441865261,to_date('8/08/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (648184749,441865261,to_date('3/02/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,444705741,to_date('3/07/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,444705741,to_date('5/06/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,444705741,to_date('3/01/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (624729530,444705741,to_date('28/02/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (681442399,445588413,to_date('12/06/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (681442399,445588413,to_date('13/04/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (681442399,445588413,to_date('16/11/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (681442399,445588413,to_date('11/01/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,450312457,to_date('7/09/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,450312457,to_date('14/03/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,450312457,to_date('8/06/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (597512357,450312457,to_date('16/11/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,451737927,to_date('2/08/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,451737927,to_date('3/11/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,451737927,to_date('8/10/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,451737927,to_date('16/03/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,453728841,to_date('25/09/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,453728841,to_date('3/08/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,453728841,to_date('6/01/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,453728841,to_date('9/03/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,456142514,to_date('28/05/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,456142514,to_date('19/06/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,456142514,to_date('9/04/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,456142514,to_date('3/02/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,456944414,to_date('4/03/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,456944414,to_date('23/06/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,456944414,to_date('8/08/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (618793789,456944414,to_date('5/04/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,457561919,to_date('7/04/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,457561919,to_date('19/10/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,457561919,to_date('24/10/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,457561919,to_date('6/05/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,459015251,to_date('13/06/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,459015251,to_date('6/04/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,459015251,to_date('13/03/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,459015251,to_date('15/09/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,461407718,to_date('23/12/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,461407718,to_date('20/01/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,461407718,to_date('9/12/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,461407718,to_date('18/12/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,463587804,to_date('3/01/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,463587804,to_date('22/11/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,463587804,to_date('16/10/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,463587804,to_date('6/01/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,469994209,to_date('2/12/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,469994209,to_date('10/11/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,469994209,to_date('27/11/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,469994209,to_date('19/05/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,486347475,to_date('18/08/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,486347475,to_date('20/04/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,486347475,to_date('12/07/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (640870972,486347475,to_date('6/07/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,489915665,to_date('25/12/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,489915665,to_date('6/06/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,489915665,to_date('26/02/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (729022449,489915665,to_date('1/02/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (564441324,492155848,to_date('14/08/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (564441324,492155848,to_date('7/07/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (564441324,492155848,to_date('31/07/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (564441324,492155848,to_date('14/09/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,492901445,to_date('9/08/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,492901445,to_date('28/04/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,492901445,to_date('18/01/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,492901445,to_date('26/10/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,496243444,to_date('16/10/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,496243444,to_date('22/01/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,496243444,to_date('9/09/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,496243444,to_date('8/12/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,498993318,to_date('5/04/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,498993318,to_date('23/10/2018 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,498993318,to_date('27/06/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,498993318,to_date('5/02/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,502061468,to_date('19/01/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,502061468,to_date('15/03/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,502061468,to_date('19/03/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,502061468,to_date('29/01/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,507229962,to_date('2/06/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,507229962,to_date('19/08/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,507229962,to_date('27/06/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,507229962,to_date('25/09/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,518946142,to_date('11/01/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,518946142,to_date('1/09/2017 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,518946142,to_date('22/03/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (701018401,518946142,to_date('3/03/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,519938764,to_date('28/02/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,519938764,to_date('8/11/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,519938764,to_date('7/03/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (627327598,519938764,to_date('23/09/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,519983920,to_date('21/08/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,519983920,to_date('3/12/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,519983920,to_date('15/05/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (615988674,519983920,to_date('31/12/2018 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,521309147,to_date('29/03/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,521309147,to_date('13/08/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,521309147,to_date('2/05/2018 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,521309147,to_date('12/01/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,531997316,to_date('28/02/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,531997316,to_date('14/09/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,531997316,to_date('9/04/2017 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (728793122,531997316,to_date('26/05/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,535070764,to_date('30/10/2018 14:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,535070764,to_date('25/11/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,535070764,to_date('15/07/2017 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (609002731,535070764,to_date('22/10/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,538296238,to_date('23/02/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,538296238,to_date('7/02/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,538296238,to_date('27/02/2018 17:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (738300572,538296238,to_date('15/02/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,539601794,to_date('1/02/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,539601794,to_date('5/02/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,539601794,to_date('21/12/2017 09:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (736358885,539601794,to_date('14/02/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752356052,541541445,to_date('13/10/2018 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752356052,541541445,to_date('24/06/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752356052,541541445,to_date('21/10/2018 15:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (752356052,541541445,to_date('12/05/2017 12:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,556904532,to_date('18/09/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,556904532,to_date('2/11/2018 13:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,556904532,to_date('9/03/2017 11:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (626592323,556904532,to_date('19/04/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (725287167,557624632,to_date('30/10/2017 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (725287167,557624632,to_date('21/07/2017 10:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (725287167,557624632,to_date('29/07/2018 16:00', 'DD/MM/YYYY HH24:MI')); 

INSERT INTO schedule (agentID,clientID,meetingTime) 
VALUES (725287167,557624632,to_date('22/06/2017 14:00', 'DD/MM/YYYY HH24:MI')); 

commit;
