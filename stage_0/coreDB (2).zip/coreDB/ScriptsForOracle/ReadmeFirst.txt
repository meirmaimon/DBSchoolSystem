
Here we have all the SQL scripts to build the initial database for the mini-project:
Run the sql files in the following order:

1) The schema definition
DB1.sql

2) The data for all the tables are inserted
area.sql
city.sql
agent.sql
client.sql
schedule.sql
 
