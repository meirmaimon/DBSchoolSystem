INSERT INTO area (areaID,areaName) 
VALUES (002,'Jerusalem'); 

INSERT INTO area (areaID,areaName) 
VALUES (003,'Center'); 

INSERT INTO area (areaID,areaName) 
VALUES (004,'North'); 

INSERT INTO area (areaID,areaName) 
VALUES (005,'Judea-Samaria'); 

INSERT INTO area (areaID,areaName) 
VALUES (008,'South'); 

INSERT INTO area (areaID,areaName) 
VALUES (009,'HaSharon'); 

commit;

