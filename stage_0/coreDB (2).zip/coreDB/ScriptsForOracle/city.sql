INSERT INTO city (cityName,areaID) 
VALUES ('Acre',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Afula',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Arad',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Ariel',5); 

INSERT INTO city (cityName,areaID) 
VALUES ('Ashdod',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Ashkelon',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Baqa-Jatt',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Bat Yam',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Beersheba',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Beit Shean',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Beit Shemesh',2); 

INSERT INTO city (cityName,areaID) 
VALUES ('Beitar Illit',5); 

INSERT INTO city (cityName,areaID) 
VALUES ('Bnei Brak',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Dimona',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Efrath',5); 

INSERT INTO city (cityName,areaID) 
VALUES ('Eilat',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Elad',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Even Yehuda',9); 

INSERT INTO city (cityName,areaID) 
VALUES ('Gan Yavne',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Gedera',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Givat Shmuel',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Givatayim',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Hadera',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Haifa',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Hertzliya',9); 

INSERT INTO city (cityName,areaID) 
VALUES ('Hod HaSharon',9); 

INSERT INTO city (cityName,areaID) 
VALUES ('Holon',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Jerusalem',2); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kafr Qasim',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Karmiel',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kfar Saba',9); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kfar Witkin',9); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kfar Yona',9); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kiryat Ata',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kiryat Bialik',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kiryat Gat',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kiryat Malakhi',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kiryat Motzkin',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kiryat Ono',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kiryat Shmona',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Kiryat Yam',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Lod',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Maale Adumim',5); 

INSERT INTO city (cityName,areaID) 
VALUES ('Maalot-Tarshiha',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Migdal HaEmek',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Modiin Illit',5); 

INSERT INTO city (cityName,areaID) 
VALUES ('Modiin-Maccabim-Reut',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Nahariya',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Nazareth',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Nazareth Illit',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Nesher',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Ness Tziona',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Netanya',9); 

INSERT INTO city (cityName,areaID) 
VALUES ('Netivot',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Ofakim',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Or Akiva',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Or Yehuda',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Petah Tikva',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Qalansawe',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Raanana',9); 

INSERT INTO city (cityName,areaID) 
VALUES ('Rahat',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Ramat Gan',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Ramat HaSharon',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Ramla',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Rehovot',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Rishon LeTzion',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Rosh HaAyin',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Safed',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Sakhnin',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Shderot',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Shfar-am',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Tamra',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Tayibe',9); 

INSERT INTO city (cityName,areaID) 
VALUES ('Tel Aviv',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Tel Mond',9); 

INSERT INTO city (cityName,areaID) 
VALUES ('Tiberias',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Tira',9); 

INSERT INTO city (cityName,areaID) 
VALUES ('Tirat Carmel',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Umm al-Fahm',4); 

INSERT INTO city (cityName,areaID) 
VALUES ('Yavne',8); 

INSERT INTO city (cityName,areaID) 
VALUES ('Yehud',3); 

INSERT INTO city (cityName,areaID) 
VALUES ('Yokneam',4); 

commit;
