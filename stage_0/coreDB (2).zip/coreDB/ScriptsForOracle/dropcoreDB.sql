drop table schedule;
drop table client;
drop table agent;
drop table city;
drop table area;

