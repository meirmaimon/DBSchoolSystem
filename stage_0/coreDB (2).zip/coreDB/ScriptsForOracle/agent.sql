INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (200320406,'Shlomo Cohen',2,6,2012,NULL,22491.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (559866704,'Shmuel  Ventura',2,6,2009,200320406,8423.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (560180780,'Moshe Suissa',2,6,2014,559866704,25151.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (560458713,'Moshe Cohen',2,7,2000,559866704,9709.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (564441324,'Yaacov Levy',2,2,1996,559866704,19012.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (569775478,'Ofer Tahar',2,0,2001,559866704,15813.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (581662917,'Gabriel Goldberg',2,7,2004,559866704,6708.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (597322737,'Moshe Amihud',3,9,2006,200320406,12495.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (597512357,'Yossef Gorodetski',3,0,2000,597322737,15494.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (604117504,'Shmuel  Bardaat',3,9,1995,597322737,14488.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (607968105,'Yehuda Azoulay',3,2,2010,597322737,23712.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (609002731,'Yoram Amichai',3,7,2014,597322737,26345.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (615988674,'Assaf Zalmanovitch',3,8,2015,597322737,25004.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (618793789,'Shimon Goldmann',3,4,1995,597322737,16505.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (624729530,'Gabriel Amichai',4,2,2016,200320406,5763.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (626592323,'Avishai Zalmanovitch',4,2,2003,624729530,24084.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (627327598,'Gabriel Cohen',4,4,2015,624729530,25277.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (640870972,'Assaf Levy',4,6,2001,624729530,28813.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (648184749,'Yoram Azoulay',4,7,2004,624729530,9210.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (650823903,'Jack Goldberg',4,3,2011,624729530,29885.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (654534078,'Yechiel Tahar',4,1,2001,624729530,23466.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (658017097,'Daniel Amihud',5,8,2008,200320406,25708.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (660084321,'Yaacov Amihud',5,6,2014,658017097,16475.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (661492247,'Yechiel Ventura',5,4,1997,658017097,28556.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (671878637,'Gabriel Suissa',5,6,2005,658017097,13128.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (676452965,'Yechiel Bardaat',5,7,2006,658017097,15007.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (676752878,'Yehuda Beneliyahu',5,8,2008,658017097,9495.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (681442399,'Ofer Beneliyahu',5,3,1995,658017097,8707.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (683733405,'Aharon Bouzaglo',8,5,2002,200320406,7778.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (701018401,'Ofer Zalmanovitch',8,4,2013,683733405,17726.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (724732338,'Yechiel Amihud',8,10,2005,683733405,25120.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (725287167,'Yehuda Benprat',8,4,2001,683733405,11239.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (726327922,'Daniel Cohen',8,5,2009,683733405,6097.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (728793122,'Amiel Gorodetski',8,8,2001,683733405,20950.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (729022449,'Avi Cohen',8,7,2004,683733405,22734.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (736358885,'Jack Suissa',9,1,1995,200320406,5778.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (738300572,'Amiel Goldberg',9,9,2002,736358885,24837.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (752297328,'Shimon Tahar',9,4,2009,736358885,28217.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (752356052,'Yoram Beneliyahu',9,2,2001,736358885,17650.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (753128485,'Zalman Bardaat',9,2,1999,736358885,9487.0); 

INSERT INTO agent (agentID,agentName,areaID,Rating,HireYear,bossID,salary) 
VALUES (756787165,'Daniel Ventura',9,4,2001,736358885,26977.0); 

commit;
