INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (2190855,'Avi Goldberg',597512357,'0507850848',NULL,'Arad'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (3389828,'Ofer Amihud',671878637,'0536155022',NULL,'Yehud'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (5000929,'Gabriel Goldmann',604117504,'0587077203',NULL,'Yavne'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (6894158,'Yoram Levy',736358885,'0525020624',NULL,'Shderot'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (8128654,'Yossef Ventura',597322737,'0520296612',NULL,'Lod'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (15801086,'Amiel Levy',729022449,'0533133558',NULL,'Rahat'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (19170372,'Jack Bouzaglo',756787165,'0507775534',NULL,'Yokneam'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (19362329,'Amiel Benprat',564441324,'0539205889',NULL,'Migdal HaEmek'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (20764142,'Zalman Levy',597512357,'0548498688',NULL,'Or Yehuda'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (22939325,'Shimon Benprat',681442399,'0537559178',NULL,'Modiin-Maccabim-Reut'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (24598464,'Yoram Ventura',658017097,'0525456700',NULL,'Netivot'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (27865530,'Yaacov Benprat',736358885,'0507675775',NULL,'Acre'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (44635211,'Assaf Goldberg',597512357,'0523925652',NULL,'Modiin-Maccabim-Reut'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (45431070,'Yaacov Zehavi',581662917,'0544609576',NULL,'Hertzliya'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (63866084,'Ofer Bardaat',560180780,'0503926479',NULL,'Kiryat Ata'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (69212955,'Aharon Goldmann',650823903,'0500188715',NULL,'Kiryat Ono'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (72356355,'Yechiel Goldmann',676752878,'0526817348',NULL,'Gedera'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (72999236,'Assaf Ventura',753128485,'0546638111',NULL,'Holon'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (73650446,'Yaacov Bardaat',681442399,'0585192626',NULL,'Eilat'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (78110558,'Avi Benprat',753128485,'0508383451',NULL,'Givat Shmuel'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (80186057,'Aharon Ventura',640870972,'0509143627',NULL,'Ramat HaSharon'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (88099555,'Moshe Gorodetski',724732338,'0501171372',NULL,'Beitar Illit'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (88526497,'Avishai BarAsher',676452965,'0583458002',NULL,'Shfar-am'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (88627833,'Shmuel  Goldmann',729022449,'0548145990',NULL,'Hod HaSharon'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (91460284,'Shmuel  Goldenberg',753128485,'0542158959',NULL,'Migdal HaEmek'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (92740097,'Aharon Goldenberg',683733405,'0520880351',NULL,'Givatayim'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (98417664,'Avishai Beneliyahu',560180780,'0585623741',NULL,'Kfar Witkin'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (98940245,'Yehuda Amichai',597322737,'0535461602',NULL,'Kiryat Malakhi'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (103047956,'Zalman Benprat',728793122,'0503353848',NULL,'Tel Aviv'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (110555065,'Amiel Zalmanovitch',597322737,'0505353020',NULL,'Nazareth'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (115115939,'Yehuda Gorodetski',724732338,'0537904299',NULL,'Kiryat Ata'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (115643127,'Assaf Tahar',627327598,'0525806044',NULL,'Maalot-Tarshiha'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (117101011,'Yaacov Tahar',559866704,'0509588429',NULL,'Acre'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (121049253,'Yehuda Ventura',738300572,'0503355905',NULL,'Ness Tziona'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (123135613,'Jack Tahar',626592323,'0540122208',NULL,'Qalansawe'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (124789264,'Shimon Azoulay',607968105,'0534474546',NULL,'Modiin Illit'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (131213514,'Yoram Zalmanovitch',753128485,'0501658904',NULL,'Or Yehuda'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (132553719,'Jack Amihud',752297328,'0501702132',NULL,'Ramat Gan'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (132793121,'Yehuda Levy',724732338,'0529315606',NULL,'Hod HaSharon'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (136037603,'Ofer Zehavi',752297328,'0504350284',NULL,'Kfar Saba'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (145310425,'Moshe Zehavi',725287167,'0549081543',NULL,'Hod HaSharon'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (153676885,'Jack Zalmanovitch',701018401,'0548217847',NULL,'Hadera'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (156366795,'Gabriel BarAsher',650823903,'0523905792',NULL,'Rehovot'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (159142131,'Yehuda Bouzaglo',726327922,'0524311369',NULL,'Netanya'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (159670900,'Yehuda Cohen',753128485,'0588596031',NULL,'Beersheba'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (168709173,'Yechiel Benprat',560180780,'0543920339',NULL,'Gedera'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (181999773,'Yoram Goldberg',607968105,'0544251072',NULL,'Ashdod'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (192493886,'Amiel Goldmann',650823903,'0524516723',NULL,'Lod'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (194361758,'Assaf Gorodetski',604117504,'0506419080',NULL,'Kfar Yona'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (210124207,'Jack Zehavi',640870972,'0534608162',NULL,'Kfar Yona'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (212847947,'Ofer Bouzaglo',724732338,'0507666934',NULL,'Lod'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (219426202,'Yossef BarAsher',609002731,'0535263354',NULL,'Haifa'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (234980567,'Yoram Goldmann',681442399,'0587127127',NULL,'Jerusalem'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (248389204,'Shimon Amichai',615988674,'0504790092',NULL,'Acre'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (249654624,'Avishai Cohen',597322737,'0534994416',NULL,'Kiryat Shmona'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (259683399,'Yossef Goldenberg',559866704,'0509256376',NULL,'Givat Shmuel'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (264966244,'Yehuda Suissa',683733405,'0581868333',NULL,'Netivot'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (265186844,'Yossef Bouzaglo',618793789,'0546107099',NULL,'Afula'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (272029654,'Amiel Amihud',607968105,'0582225064',NULL,'Kiryat Gat'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (278320006,'Avi Azoulay',640870972,'0528133488',NULL,'Tirat Carmel'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (280714288,'Yaacov Suissa',701018401,'0531541986',NULL,'Jerusalem'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (289243756,'Assaf Beneliyahu',752297328,'0585933508',NULL,'Dimona'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (310072080,'Assaf Bardaat',564441324,'0540643940',NULL,'Kiryat Ata'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (310463668,'Daniel Zehavi',729022449,'0547153838',NULL,'Nahariya'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (322919777,'Moshe Azoulay',648184749,'0524280026',NULL,'Tel Aviv'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (332265480,'Avi Tahar',725287167,'0542366045',NULL,'Kiryat Shmona'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (335190933,'Aharon Amichai',726327922,'0502603812',NULL,'Raanana'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (338857608,'Shimon Amihud',752297328,'0509733243',NULL,'Ramat Gan'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (341853362,'Daniel BarAsher',626592323,'0586628774',NULL,'Tira'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (344933268,'Zalman Amihud',752297328,'0582162179',NULL,'Ramla'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (350401127,'Yoram Zehavi',725287167,'0527197240',NULL,'Maale Adumim'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (354363890,'Shmuel  Tahar',607968105,'0589442688',NULL,'Rishon LeTzion'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (364340715,'Amiel Bardaat',200320406,'0505951586',NULL,'Qalansawe'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (378745145,'Daniel Tahar',597512357,'0586275406',NULL,'Hertzliya'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (382381035,'Shimon Ventura',650823903,'0539508550',NULL,'Eilat'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (382463885,'Daniel Zalmanovitch',683733405,'0507745709',NULL,'Ashdod'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (383479888,'Yoram Bardaat',560458713,'0523361053',NULL,'Lod'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (388665252,'Assaf Benprat',569775478,'0585704678',NULL,'Kiryat Motzkin'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (393330959,'Yechiel Cohen',752356052,'0502911562',NULL,'Kiryat Gat'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (394225733,'Gabriel Gorodetski',618793789,'0545447309',NULL,'Tel Mond'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (403013933,'Avi Levy',654534078,'0580083074',NULL,'Arad'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (410481877,'Daniel Goldberg',728793122,'0547170731',NULL,'Kiryat Gat'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (420481521,'Yoram Gorodetski',569775478,'0500916026',NULL,'Rehovot'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (435638147,'Daniel Bardaat',683733405,'0503120913',NULL,'Even Yehuda'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (435914771,'Yossef Bardaat',597322737,'0501018170',NULL,'Tira'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (436218147,'Avi Zalmanovitch',626592323,'0528985061',NULL,'Rishon LeTzion'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (440908369,'Shmuel  Amichai',627327598,'0508394164',NULL,'Ashkelon'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (441865261,'Zalman Ventura',564441324,'0540086806',NULL,'Yavne'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (444705741,'Avi Amichai',607968105,'0587037421',NULL,'Karmiel'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (445588413,'Yaacov Beneliyahu',683733405,'0526941984',NULL,'Tel Mond'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (450312457,'Moshe Benprat',752297328,'0530470493',NULL,'Ashdod'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (451737927,'Jack Ventura',597322737,'0526101663',NULL,'Lod'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (453728841,'Yehuda Bardaat',200320406,'0538773838',NULL,'Baqa-Jatt'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (456142514,'Shmuel  Benprat',640870972,'0532711588',NULL,'Kfar Witkin'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (456944414,'Yechiel Amichai',560458713,'0506001842',NULL,'Ashdod'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (457561919,'Moshe Amichai',683733405,'0588481532',NULL,'Karmiel'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (459015251,'Yossef Zehavi',756787165,'0506066808',NULL,'Nazareth'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (461407718,'Yehuda Zalmanovitch',756787165,'0544675507',NULL,'Karmiel'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (463587804,'Jack Amichai',752356052,'0531909674',NULL,'Ramat HaSharon'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (469994209,'Yehuda Goldmann',624729530,'0540580131',NULL,'Jerusalem'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (486347475,'Yechiel Zehavi',752297328,'0501980830',NULL,'Kafr Qasim'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (489915665,'Yaacov Azoulay',724732338,'0503502683',NULL,'Beit Shemesh'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (492155848,'Assaf Amihud',671878637,'0526150054',NULL,'Yavne'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (492901445,'Aharon Suissa',676452965,'0545871526',NULL,'Tirat Carmel'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (496243444,'Zalman Goldberg',581662917,'0537405971',NULL,'Ness Tziona'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (498993318,'Yehuda Zehavi',752356052,'0536690611',NULL,'Arad'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (502061468,'Yaacov Bouzaglo',615988674,'0539653189',NULL,'Or Yehuda'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (507229962,'Moshe Zalmanovitch',200320406,'0541748967',NULL,'Givat Shmuel'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (518946142,'Avishai Goldmann',581662917,'0549884675',NULL,'Beit Shemesh'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (519938764,'Zalman Azoulay',660084321,'0581941351',NULL,'Lod'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (519983920,'Daniel Suissa',560180780,'0547990653',NULL,'Beitar Illit'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (521309147,'Yechiel Zalmanovitch',683733405,'0539694675',NULL,'Beit Shean'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (531997316,'Aharon Zehavi',701018401,'0520430818',NULL,'Kiryat Bialik'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (535070764,'Yossef Beneliyahu',569775478,'0506568515',NULL,'Qalansawe'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (538296238,'Shmuel  BarAsher',660084321,'0540571861',NULL,'Kiryat Ata'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (539601794,'Jack Benprat',676452965,'0536437716',NULL,'Haifa'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (541541445,'Yossef Goldmann',597322737,'0539325488',NULL,'Modiin Illit'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (556904532,'Avi Bouzaglo',581662917,'0534819405',NULL,'Afula'); 

INSERT INTO client (clientID,clientName,agentID,phoneNr,Address,cityName) 
VALUES (557624632,'Zalman BarAsher',607968105,'0537641907',NULL,'Arad'); 

commit;
